var WEBPACK_NAME = "webpack.config.js";
var MAIN_JS_NAME = "game.js";
var GAME_CONFIG_JSONS_NAME = "manifest.json";
var QGAME_ADAPTER_NAME = "qgame-adapter.js";
var BABELRC_NAME = ".babelrc";

var path = require('path');
var fs = require('fs');

var zipRootPath;
let RUNTIME_CONFIG;

// 导出的游戏过程目录名称
var QGAME_NAME = "qgame";
var SRC_NAME = "src";
var CONFIG_NAME = "config";
var ENGINE_NAME = "engine";
var SIGN_NAME = "sign";

// 导出的快游戏根目录
var dirTarget;
// cp配置的应用图标路径
var iconPath;
// 写入manifest.json的应用图标的路径

var npmPath;
var runRelease;
var VIVOExternals = {};

// 获取资源文件
function getResPath(name) {
    var resPath = path.join(__dirname, "res");
    return path.join(resPath, name);
}

// 添加不需要编译的js
function handleExternalFile(dir, rootPath) {
    var list = fs.readdirSync(dir);

    list.forEach(function (filePath) {
        var fullPath = path.join(dir, filePath);
        var stat = fs.statSync(fullPath);

        if (stat && stat.isDirectory()) {
            handleExternalFile(fullPath, rootPath);
        } else {
            var fileExt = path.extname(fullPath);
            if (fileExt === ".js") {
                var relativeToZipPath = fullPath.slice(rootPath.length + 1, fullPath.length);

                // 去除 main.js 以及 jsb-adapter 下除了 index.js 的文件
                if (relativeToZipPath !== "main.js" &&
                    (relativeToZipPath.indexOf("jsb-adapter") !== 0 || filePath === "index.js")) {

                    // 替换 \\ 为 /
                    relativeToZipPath = relativeToZipPath.replace(/\\/g, '/');
                    VIVOExternals[relativeToZipPath] = "commonjs " + relativeToZipPath;
                }
            }
        }
    });
}

function zipVIVOExternals() {
    var webpackName = WEBPACK_NAME;
    var webpackSource = getResPath(webpackName);
    var webpackContent = fs.readFileSync(webpackSource, "utf8");
    // 导出的快游戏config目录
    var configTarget = path.join(dirTarget, CONFIG_NAME);

    webpackContent = webpackContent.replace("EXTERNALS_PLACEHOLDER", JSON.stringify(VIVOExternals));

    // config目录若存在
    if (fs.existsSync(configTarget)) {
        deleteDir(configTarget);
    }
    fs.mkdirSync(configTarget);
    // 在游戏工程的config目录里添加webpack.config.js
    fs.writeFileSync(path.join(configTarget, WEBPACK_NAME), webpackContent);
}

function writeConfigFile() {
    var cfgName = 'game.config.json';
    var projectCgfFile = path.join(Editor.projectPath, cfgName);
    var package = RUNTIME_CONFIG.package;
    var name = RUNTIME_CONFIG.name;
    var versionName = RUNTIME_CONFIG.versionName;
    var versionCode = RUNTIME_CONFIG.versionCode;
    var minPlatformVersion = RUNTIME_CONFIG.minPlatformVersion;
    var deviceOrientation = RUNTIME_CONFIG.deviceOrientation;
    var logLevel = RUNTIME_CONFIG.logLevel;

    var jsonObj = {
        "package": package,
        "name": name,
        "icon": `/image/${path.parse(iconPath).base}`,
        "versionName": versionName,
        "versionCode": versionCode,
        "minPlatformVersion": minPlatformVersion,
        "deviceOrientation": deviceOrientation,
        "type": "game",
        "config": {
            "logLevel": logLevel
        },
        "display": {
        }
    };
    var jsonStr = JSON.stringify(jsonObj);
    fs.writeFileSync(projectCgfFile, jsonStr);
}

function handleSrc() {
    var mainName = 'main.js';
    var fileMain = path.join(zipRootPath, mainName);
    var mainString = fs.readFileSync(fileMain, "utf8");

    mainString = mainString.replace('window.jsb', 'window.qg');

    var index = mainString.indexOf("require('src/settings");

    mainString = mainString.slice(0, index) + "require('src/qgame-adapter.js');\n\t" + mainString.slice(index);
    fs.writeFileSync(fileMain, mainString);

    // 导出的快游戏src目录
    var srcTarget = path.join(dirTarget, SRC_NAME);
    // 如果src目录存在，则先删除再创建目录
    if (fs.existsSync(srcTarget)) {
        deleteDir(srcTarget)
    }
    fs.mkdirSync(srcTarget);
    // 添加game.js
    fs.writeFileSync(path.join(srcTarget, MAIN_JS_NAME), mainString);

    var cfgName = 'game.config.json';
    var projectCgfFile = path.join(Editor.projectPath, cfgName);

    fs.writeFileSync(path.join(srcTarget, GAME_CONFIG_JSONS_NAME), fs.readFileSync(projectCgfFile));

    var imagePath = path.join(srcTarget, 'image');
    // 判断游戏过程里image目录是否存在
    if (fs.existsSync(imagePath)) {
        deleteDir(imagePath)
    }
    fs.mkdirSync(imagePath);
    // 添加应用图标
    fs.writeFileSync(path.join(imagePath, path.parse(iconPath).base), fs.readFileSync(iconPath));
}

// 处理debug模式的签名
function handleSign(dirSign) {
    // 导出的快游戏sign目录
    var signTarget = path.join(dirTarget, SIGN_NAME);
    // sign目录若存在，则删除
    if (fs.existsSync(signTarget)) {
        deleteDir(signTarget);
    }
    fs.mkdirSync(signTarget);
    // 将creator导出的sign目录拷贝到游戏过程的sign目录里，creator导出的sign目录包含cp配置的release签名
    copyDir(dirSign, signTarget);

    var debugPath = path.join(signTarget, 'debug');
    // 创建sign里的debug目录
    fs.mkdirSync(debugPath);

    var fullPath = getResPath("certificate.pem");
    // 添加debug模式的certificate.pem
    fs.writeFileSync(path.join(debugPath, 'certificate.pem'), fs.readFileSync(fullPath));
    fullPath = getResPath("private.pem");
    // 添加debug模式的private.pem
    fs.writeFileSync(path.join(debugPath, 'private.pem'), fs.readFileSync(fullPath));
}

function handlePackage() {
    var fullPath = getResPath("package.json");
    //添加 package.json到游戏过程目录
    fs.writeFileSync(path.join(dirTarget, 'package.json'), fs.readFileSync(fullPath));
}

// 处理engine目录
function handleEngine(dirRes, dirSrc, dirAdapter, event) {
    // 导出的快游戏engine目录
    var engineTarget = path.join(dirTarget, ENGINE_NAME);
    // 如果src目录存在，则先删除再创建目录
    if (fs.existsSync(engineTarget)) {
        deleteDir(engineTarget);
    }
    fs.mkdirSync(engineTarget);

    // 将creator导出的res、src、jsb-adapter目录拷贝到游戏过程的engine目录里
    copyDir(dirSrc, path.join(engineTarget, 'src'));
    copyDir(dirAdapter, path.join(engineTarget, 'jsb-adapter'));
    var isTinyPackage = RUNTIME_CONFIG.tinyPackageMode;
    var target = path.join(engineTarget, 'jsb-adapter');
    var rtAdapterTarget = path.join(target, 'engine/rt-adapter.js');
    var jsbAdapterIndexPath = path.join(target, "engine/index.js");
    var requireStr = "\nrequire(\'jsb-adapter\/engine\/rt-adapter.js\');";
    if (isTinyPackage === true) {
        var remoteServer = RUNTIME_CONFIG.tinyPackageServer || '';
        remoteServer = remoteServer.trim();
        if (remoteServer === '') {
            event.reply(new Error("please enter remote server root"));
            return;
        }

        // 将 rt-adapter.js 文件添加到 engine 目录中
        var rtAdapterPath = getResPath('rt-adapter.js');
        var rtAdapterStr = fs.readFileSync(rtAdapterPath, "utf8");
        rtAdapterStr = rtAdapterStr.replace('REMOTE_SERVER_ROOT_PLACE_HOLDER', remoteServer);
        fs.writeFileSync(rtAdapterTarget, rtAdapterStr);

        // 为 index.js 文件添加引入 rt-adapter.js
        var indexStr = fs.readFileSync(jsbAdapterIndexPath, "utf8");
        indexStr += requireStr
        fs.writeFileSync(jsbAdapterIndexPath, indexStr);
    } else {
        //非小包模式才拷贝资源，否则让用户自己拷贝资源到自己的服务端中
        copyDir(dirRes, path.join(engineTarget, 'res'))
    }
}

function onBeforeBuildFinish(event, options) {
    Editor.log('Checking config file ' + options.dest);
    // 导出的游戏过程目录路径
    dirTarget = path.resolve(options.dest, '..', `./${QGAME_NAME}`);

    if (!fs.existsSync(dirTarget)) {
        fs.mkdirSync(dirTarget)
    }

    Editor.log('Building game ' + options.platform + ' to ' + dirTarget);

    // 将配置信息写入game.config.json
    writeConfigFile();

    zipRootPath = options.dest;

    var dirRes = path.join(options.dest, 'res');
    var dirSrc = path.join(options.dest, 'src');
    var dirAdapter = getResPath('jsb-adapter');
    var dirSign = path.join(options.dest, 'sign');
    var qgamePath = getResPath(QGAME_ADAPTER_NAME);
    var babelrcPath = getResPath(BABELRC_NAME);

    // 将.babelrc 拷贝到快游戏工程目录
    fs.writeFileSync(path.join(dirTarget, BABELRC_NAME), fs.readFileSync(babelrcPath));
    // 将qgame-adapter.js拷贝到 dirSrc 目录下
    fs.writeFileSync(path.join(dirSrc, QGAME_ADAPTER_NAME), fs.readFileSync(qgamePath));
    // 处理 src 目录
    handleSrc();
    // 导出 sign 目录
    handleSign(dirSign);
    // 处理 package.json
    handlePackage();
    // 导出 engine目录
    handleEngine(dirRes, dirSrc, dirAdapter, event);
    // 处理不需要编译的文件
    var dirList = [{
        dir: dirRes,
        rootPath: zipRootPath
    }, {
        dir: dirSrc,
        rootPath: zipRootPath
    }, {
        dir: dirAdapter,
        rootPath: path.join(__dirname, "res")
    }];

    dirList.forEach(item => {
        handleExternalFile(item.dir, item.rootPath);
    });
    // 添加 webpack.config.js 文件
    zipVIVOExternals();

    // 导出rpk包
    if (npmPath) {
        var exec = require('child_process').exec;
        var npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';

        if (process.env.PATH.indexOf(npmPath) === -1) {
            process.env.PATH += `:${npmPath}`;
        }

        // 构建rpk包
        function build() {
            Editor.log(`开始构建rpk包!`);

            exec(`${npmCmd} run ${runRelease ? "release" : "build"}`, {
                env: process.env,
                cwd: dirTarget
            }, (error) => {
                if (!error) {
                    Editor.log(`rpk包构建完成! `);
                    event.reply();
                }
                else {
                    Editor.log(`rpk包构建失败！错误：${error}`);
                }
            })
        }

        // 如果已安装npm包，直接构建rpk包
        if (fs.existsSync(path.join(dirTarget, 'node_modules'))) {
            build();
        }
        else {
            Editor.log('开始安装快游戏依赖的npm包，请耐心等待...');
            // 安装依赖的npm包
            exec(`${npmCmd} install`, {
                env: process.env,
                cwd: dirTarget
            }, (error) => {
                if (!error) {
                    Editor.log(`依赖的npm包安装完成！`);
                    build();
                }
                else {
                    Editor.log(`依赖的npm包安装失败！错误：${error}`);
                }
            })
        }
    }
    else {
        Editor.log('导出快游戏工程目录完成，由于您未配置本地npm安装路径，无法构建rpk包！');
        event.reply();
    }
}

// 删除目录
function deleteDir(dirPath) {
    let files = fs.readdirSync(dirPath);

    for (var i = 0; i < files.length; i++) {
        let newPath = path.join(dirPath, files[i]);
        let stat = fs.statSync(newPath);

        if (stat.isDirectory()) {
            deleteDir(newPath);
        } else {
            fs.unlinkSync(newPath);
        }
    }

    fs.rmdirSync(dirPath)
}

// 拷贝目录
function copyDir(src, dist, callback = () => { }) {
    if (fs.existsSync(dist) !== true) {
        fs.mkdirSync(dist);
    }
    _copy(src, dist);

    function _copy(src, dist) {
        if (fs.existsSync(src) !== true) {
            return;
        }
        var paths = fs.readdirSync(src);
        paths.forEach(function (item) {
            const _src = path.join(src, item);
            const _dist = path.join(dist, item);
            const stat = fs.statSync(_src);

            // 判断是文件还是目录
            if (stat.isFile()) {
                if (_src.indexOf('jsb-adapter/jsb-builtin') === -1) {
                    fs.writeFileSync(_dist, fs.readFileSync(_src));
                }
            } else if (stat.isDirectory()) {
                // 当是目录是，递归复制
                copyDir(_src, _dist, callback)
            }
        });
    }
}

//先读取runtime相应的配置信息
function loadRuntimeSettings(event, options) {
    var value = Editor.Profile.load('profile://project/cpk-publish.json');
    RUNTIME_CONFIG = value.data;
    var package = RUNTIME_CONFIG.package;
    var name = RUNTIME_CONFIG.name;
    var icon = RUNTIME_CONFIG.icon;
    var versionName = RUNTIME_CONFIG.versionName;
    var versionCode = RUNTIME_CONFIG.versionCode;
    var minPlatformVersion = RUNTIME_CONFIG.minPlatformVersion;

    npmPath = RUNTIME_CONFIG.npmPath;
    runRelease = RUNTIME_CONFIG.runRelease;
    iconPath = icon ? path.join(Editor.projectPath, icon) : '';

    var configList = [{
        name: '应用包名',
        value: package
    }, {
        name: '应用名称',
        value: name
    }, {
        name: '应用图标',
        value: icon
    }, {
        name: '应用版本名称',
        value: versionName
    }, {
        name: '应用版本号',
        value: versionCode
    }, {
        name: '支持的最小平台版本号',
        value: minPlatformVersion
    }];

    // 配置字段校验
    var validator = true;
    var nameList = [];
    var errorText = '';
    configList.forEach(function (item) {
        if (!item.value) {
            validator = false;
            nameList.push(item.name);
        }
    });

    if (!validator) {
        errorText += nameList.join('、') + "不能为空！";
    }

    if (icon) {
        if (!fs.existsSync(iconPath)) {
            validator = false;
            errorText += '该' + icon + '路径下，图片不存在！';
        }
    }

    var releaseSign = path.join(options.dest, "sign", "release");

    if (runRelease && (!fs.existsSync(path.join(releaseSign, 'certificate.pem')) || !fs.existsSync(path.join(releaseSign, 'private.pem')))) {
        validator = false;
        errorText += 'release 签名不存在！';
    }

    if (!validator) {
        event.reply(new Error(errorText));
        return;
    }

    onBeforeBuildFinish(event, options);
}

module.exports = {
    name: 'vivo 快游戏',
    platform: 'runtime',
    extends: Editor.isWin32 ? 'win32' : 'mac',
    buttons: [
        Editor.Builder.DefaultButtons.Build,
        { label: Editor.T('BUILDER.play'), message: 'play' },
    ],
    messages: {
        'build-finished': loadRuntimeSettings,
    },
    settings: Editor.url('packages://cpk-publish/build-runtime-ui.js')
};