/**
 * Created by wzm on 20/07/2018.
 */

'use strict';

exports.template = `
        <ui-prop name="应用包名" auto-height>
            <ui-input class="flex-1" placeholder="请输入应用包名，如：com.example.demo" v-value="runtimeSetting.package"></ui-input>
        </ui-prop>

        <ui-prop name="应用名称" auto-height>
            <ui-input class="flex-1" placeholder="请输入应用名称" v-value="runtimeSetting.name"></ui-input>
        </ui-prop>

        <ui-prop name="应用图标" auto-height>
            <ui-input class="flex-1" placeholder="请输入应用图标路径，如：/assets/image/logo.png" v-value="runtimeSetting.icon"></ui-input>
        </ui-prop>

        <ui-prop name="应用版本名称" auto-height>
            <ui-input class="flex-1" placeholder="请输入应用版本名称，如：1.0.0" v-value="runtimeSetting.versionName"></ui-input>
        </ui-prop>

        <ui-prop name="应用版本号" auto-height>
            <ui-input class="flex-1" placeholder="请输入应用版本号，如：1" v-value="runtimeSetting.versionCode"></ui-input>
        </ui-prop>

        <ui-prop name="支持的最小平台版本号" auto-height>
            <ui-input class="flex-1" placeholder="请输入支持的最小平台版本号，如：1000" v-value="runtimeSetting.minPlatformVersion"></ui-input>
        </ui-prop>

        <ui-prop name="屏幕方向">
            <ui-select class="flex-1" v-value="runtimeSetting.deviceOrientation">
                <option value="portrait">竖屏</option>
                <option value="landscape">横屏</option>
            </ui-select>
        </ui-prop>

        <ui-prop name="打印日志等级">
            <ui-select class="flex-1" v-value="runtimeSetting.logLevel">
                <option value="log">log</option>
                <option value="off">off</option>
                <option value="error">error</option>
                <option value="warn">warn</option>
                <option value="info">info</option>
                <option value="debug">debug</option>
            </ui-select>
        </ui-prop>
        <ui-prop name="本地npm安装路径" auto-height>
            <ui-input class="flex-1" placeholder="请输入本地的npm安装路径" v-value="runtimeSetting.npmPath"></ui-input>
        </ui-prop>
        <ui-prop name="构建发布程序包" auto-height>
            <ui-checkbox class="flex-1" v-value="runtimeSetting.runRelease"></ui-input>
        </ui-prop>
`;

exports.name = 'runtime';

exports.data = function () {
    return {
        runtimeSetting: {
            "package": "",
            "name": "",
            "icon": "",
            "versionName": "",
            "versionCode": "",
            "minPlatformVersion": "",
            "deviceOrientation": "portrait",
            "npmPath": "",
            "runRelease": false
        },
        //记录原来的EncryptJs的选项
        originEncryptJs: false,
        profile: null,
    };
};

exports.watch = {
    runtimeSetting: {
        handler(val){
            Object.assign(this.profile.data, this.runtimeSetting);
            this.profile.save();
        },
        deep: true,
    }
};

exports.created = function () {
    this.originEncryptJs = this.project.encryptJs;
    this.project.encryptJs = false;
    Editor.Profile.load('profile://project/cpk-publish.json', (err, ret) => {
        if (err) return;
        this.profile = ret;
        this.runtimeSetting = ret.data;
    });
};

exports.directives = {};
exports.destroyed = function () {
    this.project.encryptJs = this.originEncryptJs;
};

exports.methods = {};